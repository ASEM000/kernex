from __future__ import annotations
from typing import Sequence ,Callable

import jax 
import jax.numpy as jnp 

import functools

# def fgrad(func,**kwargs):

#     def _fgrad(
#         func,
#         offsets=(0,1),
#         step_size=1e-2,
#         derivative=1,
#         argnums=0):
        
#         assert isinstance(derivative,int) and derivative>0,\
#             f"derivative must be a positive integer."
        
#         assert step_size>0,\
#             f"step_size must be a positive float"

#         if isinstance(argnums,int):
#             argnums = (argnums,)
        
#         elif isinstance(argnums,Sequence):
#             assert all(isinstance(argnum,int)  for argnum in argnums),\
#                 ("argnums must be Sequence of int."
#                 f"Found {argnums}")
        
#         else :
#             raise ValueError(f"argnums must be int or a Sequence of ints.Found {argnums}")
        
#         offsets = jnp.array(offsets)
        

#         def __argnum_call__(func:Callable,argnum:int)->Callable:
#             """differentiate per argnum"""
            
#             def wrapper(*x):
#                 x = jnp.array(x) 
#                 coeffs = generate_coeffs(offsets,derivative) 
#                 dx = offsets * step_size # array
#                 x = jnp.zeros([len(coeffs),len(x)]).at[:,argnum].set(dx.T) + x
#                 return jnp.sum(coeffs*jax.vmap(
#                     lambda args:func(*args))(x))/(step_size**derivative)
#             return wrapper
        
#         @functools.wraps(func)
#         def __argnums_call__(*x):

#             if len(argnums)>1:
#                 return tuple(__argnum_call__(func,argnum)(*x) 
#                     for argnum in argnums)
            
#             else:
#                 return __argnum_call__(func,argnums[0])(*x)

#         return __argnums_call__


#     if len(kwargs)>0 :  
#         # inline  mode
#         return _fgrad(func,**kwargs)
    
#     else :
#         # @decorator
#         @functools.wraps(func)
#         def call(*ar,**kw):
#             return _fgrad(func)(*ar,**kw)
#         return call

def fgrad(func,**kwargs):

    def __fgrad(
        func,
        offsets=(0,1),
        step_size=1e-3,
        derivative=1,
        argnum=0):
        
        offsets = jnp.array(offsets)
        coeffs = generate_coeffs(offsets=offsets,derivative=derivative)
        dX = offsets * step_size

        def __call__(*args):
            return sum(
                [ coeff* func(*[ arg + (dx if i == argnum else 0) for i,arg in enumerate(args) ]) 
                    for coeff,dx in zip(coeffs,dX)])/(step_size**derivative)

        return __call__ 


    def _fgrad(
        func,
        offsets=(-2,-1,0,1,2),
        step_size=1e-3,
        derivative=1,
        argnums=(0,)):

        # assert isinstance(derivative,int) and derivative>0,\
        #     f"derivative must be a positive integer."
        
        # assert step_size>0,\
        #     f"step_size must be a positive float"

        if isinstance(argnums,int):
            argnums = (argnums,)
        
        elif isinstance(argnums,Sequence):
            assert all(isinstance(argnum,int)  for argnum in argnums),\
                ("argnums must be Sequence of int."
                f"Found {argnums}")

        if len(argnums) == 1 :
            return __fgrad(func,offsets,step_size,derivative,argnums[0])
        else :
            return tuple(__fgrad(func,offsets,step_size,derivative,argnum) 
                for argnum in argnums)

    if len(kwargs)>0 :  
        # inline  mode
        return _fgrad(func,**kwargs)
    
    else :
        # @decorator
        @functools.wraps(func)
        def call(*ar,**kw):
            return _fgrad(func)(*ar,**kw)
        return call
    


@functools.partial(jax.jit,static_argnums=(1,))
def generate_coeffs( 
    offsets:tuple[float|int,...], 
    derivative : int ) -> tuple[float] :
    
    """Generate FD coeffs"""
    # https://en.wikipedia.org/wiki/Finite_difference_coefficient


    N = len(offsets)
    assert  derivative < N ,\
        ("sampling points must be larger than derivative order.\n" ,
        f"Found len({offsets})={len(offsets)} < {derivative}" )

    A = jnp.repeat(jnp.array(offsets)[None,:],repeats=N,axis=0) 
    A **= jnp.arange(0,N).reshape(-1,1)
    index = jnp.arange(N) 
    factorial = jnp.prod(jnp.arange(1,derivative+1))
    B = jnp.where( index == derivative ,  factorial , 0)[:,None]
    C = jnp.linalg.inv(A)@B
    
    return C.flatten()



def fdiff(func:Callable,*args,**kwargs):
  
    # inline diff
    if len(args) > 0 or len(kwargs)>0 :
        return fgrad(lambda *ar,**kw : jnp.sum(func(*ar,**kw)),*args,**kwargs)

    # @decorator diff with call
    elif len(args)== 0 and len(kwargs)==0 :

        @functools.wraps(func)
        def call(*ar,**kws):
            return fgrad(lambda *ar,**kws : jnp.sum(func(*ar,**kws)))(*ar,**kws)
        return call