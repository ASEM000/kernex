from typing import Any, Callable

import jax
import jax.numpy as jnp
import numpy as np
import optax
from tqdm import tqdm

import kernex
from experimental import nn as nn
from experimental.nn import AdaptiveReLU, Conv2D, MaxPool2D, Upsample2D
from kernex.treeclass.decorator import static_field, treeclass


def test_nn():

    # problem setup
    nt, nz = 32, 32
    tmin, tmax = 0., 0.5
    zmin, zmax = 0., 1.

    dt = (tmax - tmin) / (nt - 1)
    dz = (zmax - zmin) / (nz - 1)

    tspace = np.linspace(tmin, tmax, nt)
    zspace = np.linspace(zmin, zmax, nz)
    T, Z = np.meshgrid(tspace, zspace, indexing='ij')

    ## -------------- numerical solution -------------------------------------- ##

    @jax.vmap
    @jax.vmap
    def Q_func(X):
        # fixed flow rate
        return 1.66

    @jax.vmap
    @jax.vmap
    def cfunc(t, z):
        flow_rate = 1.66
        return jnp.sin(2 * np.pi * jnp.maximum(t - z / flow_rate, 0))

    solve = kernex.sscan(kernel_size=(2, 3, 3),
                         offset=(0, (1, 0), (1, 0)),
                         named_axis={
                             1: 't',
                             2: 'i'
                         },
                         relative=True)

    def nonlinear_wave(X, dt, dz):
        return (X[0, 't-1', 'i'] - X[1, 't-1', 'i'] * dt / dz *
                (X[0, 't-1', 'i'] - X[0, 't-1', 'i-1']))

    # apply nonlinear wave on concentration
    solve[0, :, :] = nonlinear_wave
    # solve[1,:,:] = lambda x,y,z : x[0,'t','i'] # identity function

    QN0 = Q_func(Z)
    CN0 = np.zeros([nt, nz])
    CN0[:, 0] = np.maximum(np.sin(2 * np.pi * (T[:, 0])), 0)  # set IC

    func = lambda q: solve(q, dt, dz)

    QN = jnp.ones_like(CN0) * Q_func(Z)
    CNf, QNf = func(jnp.stack([CN0, QN]))

    CAf = cfunc(T, Z)

    nonlinear_wave_partial = lambda Q: solve(jnp.stack([CN0, Q[0, 0]], axis=0),
                                             dt, dz)[0][None, None]

    ## -------------------------------------- NN+FDM -------------------------------------- ##

    @treeclass
    class AutoEncoder:

        conv1: Any
        relu1: Any
        maxp1: Any

        conv2: Any
        relu2: Any
        maxp2: Any

        upsample1: Any
        deconv1: Any
        relu3: Any

        upsample2: Any
        deconv2: Any
        relu4: Any

        cpool: Any

        def __init__(self, key: jax.random.PRNGKey):

            keys = jax.random.split(key, 5)

            # encoder
            self.conv1 = Conv2D(in_channels=1,
                                out_channels=8,
                                kernel_size=(3, 3),
                                key=keys[0])
            self.relu1 = AdaptiveReLU()
            self.maxp1 = MaxPool2D(kernel_size=(2, 2), strides=2)

            self.conv2 = Conv2D(in_channels=8,
                                out_channels=32,
                                kernel_size=(3, 3),
                                key=keys[1])
            self.relu2 = AdaptiveReLU()
            self.maxp2 = MaxPool2D(kernel_size=(2, 2), strides=2)

            # decoder
            self.upsample1 = Upsample2D(scale=2)
            self.deconv1 = Conv2D(in_channels=32,
                                  out_channels=32,
                                  kernel_size=(3, 3),
                                  key=keys[2])
            self.relu3 = AdaptiveReLU()

            self.upsample2 = Upsample2D(scale=2)
            self.deconv2 = Conv2D(in_channels=32,
                                  out_channels=8,
                                  kernel_size=(3, 3),
                                  key=keys[3])
            self.relu4 = AdaptiveReLU()

            self.cpool = Conv2D(in_channels=8,
                                out_channels=1,
                                kernel_size=(3, 3),
                                key=keys[4])

        def __call__(self, x):

            x = self.conv1(x)
            x = self.relu1(x)
            x = self.maxp1(x)

            x = self.conv2(x)
            x = self.relu2(x)
            x = self.maxp2(x)

            x = self.upsample1(x)
            x = self.deconv1(x)
            x = self.relu3(x)

            x = self.upsample2(x)
            x = self.deconv2(x)
            x = self.relu4(x)

            x = self.cpool(x)

            return x

    @treeclass
    class AutoEncoderFDM:
        ae: AutoEncoder
        fdm: Callable = static_field()

        def __init__(self, key):
            self.ae = AutoEncoder(key=key)
            self.fdm = lambda Q: solve(jnp.stack([CN0, Q[0, 0]], axis=0), dt,
                                       dz)[0][None, None]

        def __call__(self, x):
            x = self.ae(x)
            x = self.fdm(x)
            return x

    model = AutoEncoderFDM(jax.random.PRNGKey(0))

    input_dim = (1, 1, nt, nz)

    print(f"{model!r}")

    print(kernex.viz.tree_box(model,array=jnp.ones(input_dim)))

    print(kernex.viz.summary(model))

    print(kernex.viz.tree_diagram(model))

    @jax.jit
    def loss_func(model, Cf, C0):
        '''
        --- Args
            params : dict of weights and biases
            Cf     : final solution of concentration solution
            C0     : inital solution of concentration solution
        
        --- Steps
            [1] predict a flow rate 2D plane
            [2] use C0,predicted Q to numerically solve linear wave based on FDM
            [3] compare result of [2] with Cf (Experimental result)
        '''

        # Predicted flow rate based on experimental input
        Cp = model(Cf[None, None])[0, 0]

        # Compare predicted concentration with experimental concentration
        return jnp.mean((Cp - Cf)**2)

    optimizer = optax.adam(1e-3)
    opt_state = optimizer.init(model)

    @jax.jit
    def step(opt_state, model, Cf, C0, lr: float = 1e-3):
        # get loss value and gradient with respect to params
        value, grads = jax.value_and_grad(loss_func, 0)(model, Cf, C0)
        updates, opt_state = optimizer.update(grads, opt_state)
        model = optax.apply_updates(model, updates)
        return opt_state, (value, model)

    epochs = 1000
    for i in tqdm(range(1, 1 + epochs)):

        opt_state, (value, model) = step(opt_state, model, CNf, CN0, lr=1e-4)

        if i % 1000 == 0:
            Cpred = model(CNf[None, None])[0, 0]
            Qpred = model.ae(CNf[None, None])[0, 0]
            '''Qmean is calculated on non boundary region with C>0 '''
            QpredMean = Qpred * jnp.where(CNf > 0, 1, 0)  # set Q = 0 for C=0
            QpredMean = QpredMean[1:-1, 1:-1]  # exclude boundary
            QpredMean = QpredMean[jnp.where(
                QpredMean != 0)]  # get all non zero values
            print(
                f'epoch={i:003d}\tloss={value:.3e}\tQmean={jnp.mean(QpredMean)}'
            )

    return np.testing.assert_allclose(jnp.mean(QpredMean), 1.66, atol=0.1)
