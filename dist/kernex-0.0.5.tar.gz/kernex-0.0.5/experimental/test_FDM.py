
from experimental.FDM import fgrad ,generate_coeffs
from jax import numpy as jnp 
import jax 
import numpy as np 


def test_coefficients():
    DF = lambda N :generate_coeffs(N,1)


    all_correct = lambda x,y : np.testing.assert_allclose(x,y,atol=1e-2)

    # https://en.wikipedia.org/wiki/Finite_difference_coefficient
    all_correct( DF((0,1))           , jnp.array([-1.,1.]) )
    all_correct( DF((0,1,2))         , jnp.array([-3/2.,2.,-1/2]) )
    all_correct( DF((0,1,2,3))       , jnp.array([-11/6,	3.,	-3/2,	1/3	]) )
    all_correct( DF((0,1,2,3,4))     , jnp.array([-25/12,	4.,	-3.,	4/3	,-1/4	 ]) )
    all_correct( DF((0,1,2,3,4,5))   , jnp.array([-137/60,	5.,	-5,	10/3,	-5/4,	1/5	]) )
    all_correct( DF((0,1,2,3,4,5,6)) , jnp.array([-49/20,	6.,	-15/2,	20/3,	-15/4,	6/5,	-1/6]) )
    
    # https://web.media.mit.edu/~crtaylor/calculator.html
    all_correct( DF((-2.2,3.2 , 5))  , jnp.array([-205/972,280/972,-75/972]) )

def test_fgrad():

    all_correct = lambda lhs,rhs : np.testing.assert_allclose(lhs,rhs,atol=0.15)


    for func in [lambda x:x,lambda x:x**2,lambda x:x+2] :
        f1 = jax.grad(func)
        f2 = fgrad(func)
        args = (1.,)
        F1,F2 = f1(*args),f2(*args)
        all_correct(F1,F2)

    for func in [lambda x,y:x+y,lambda x,y:x**2+y**3,lambda x,y:x+2+y*x] :
        f1 = jax.grad(func)
        f2 = fgrad(func)
        args = (1.,2.)
        F1,F2 = f1(*args),f2(*args)
        all_correct(F1,F2)
    
    for func in [lambda x,y,z:x+y+z,lambda x,y,z:x**2+y**3*z,lambda x,y,z:x+2+y*x+z] :
        f1 = jax.grad(func)
        f2 = fgrad(func)
        args = (1.,2.,3.)
        F1,F2 = f1(*args),f2(*args)
        all_correct(F1,F2)
    

    # test argnums
    func = lambda x,y,z:x**2+y**3+z**4
    f1 = jax.grad(func,argnums=(0,))(1.,1.,1.)
    f2 = fgrad(func,argnums=(0,))(1.,1.,1.)
    all_correct(f1,f2) 

    f1 = jax.grad(func,argnums=(1,))(1.,1.,1.)
    f2 = fgrad(func,argnums=(1,))(1.,1.,1.)
    all_correct(f1,f2) 


    f1 = jax.grad(func,argnums=(2,))(1.,1.,1.)
    f2 = fgrad(func,argnums=(2,))(1.,1.,1.)
    all_correct(f1,f2) 

    func = jnp.sin
    f1 = jax.grad(jax.grad(func))(10.)
    f2 = fgrad(func,derivative=2)(10.)
    all_correct(f1,f2) 