"""neural network layers based subclassing `treeclass`"""

from __future__ import annotations

from typing import Sequence

import jax
from jax import numpy as jnp

import kernex
from kernex.treeclass.decorator import static_field, treeclass


@treeclass
class Conv2D:

    weight: jnp.ndarray
    bias: jnp.ndarray

    in_channels: int = static_field()
    out_channels: int = static_field()
    kernel_size: tuple[int, ...] | int = static_field()
    strides: tuple[int, ...] | int = static_field()
    padding: tuple[int, ...] | int | str = static_field()

    def __init__(self,
                 *,
                 in_channels,
                 out_channels,
                 kernel_size,
                 strides=1,
                 padding=("same", "same"),
                 key=jax.random.PRNGKey(0),
                 use_bias=True,
                 kernel_initializer=jax.nn.initializers.kaiming_uniform()):

        self.weight = kernel_initializer(
            key, (out_channels, in_channels, *kernel_size))
        self.bias = (jnp.zeros(
            (out_channels, *((1, ) * len(kernel_size)))) if use_bias else None)

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.strides = strides
        self.padding = ("valid", ) + padding

    def __call__(self, x):
                
        @kernex.kmap(kernel_size=(self.in_channels, *self.kernel_size),
                     strides=self.strides,
                     padding=self.padding)
        def _conv2d(x, w):
            return jnp.sum(x * w)

        @jax.vmap 
        def fwd_image(image):
            return jax.vmap(lambda w: _conv2d(image, w))(self.weight)[:, 0] + (
                self.bias if self.bias is not None else 0)

        return fwd_image(x)


@treeclass
class MaxPool2D:

    kernel_size: tuple[int, ...] | int = static_field()
    strides: tuple[int, ...] | int = static_field()
    padding: tuple[int, ...] | int | str = static_field()

    def __init__(self, *, kernel_size=(2, 2), strides=2, padding="valid"):

        self.kernel_size = kernel_size
        self.strides = strides
        self.padding = padding

    def __call__(self, x):
        
        @jax.vmap
        @jax.vmap 
        @kernex.kmap(kernel_size=self.kernel_size,
                     strides=self.strides,
                     padding=self.padding)
        def _maxpool2d(x):
            return jnp.max(x)

        return _maxpool2d(x)


@treeclass
class Upsample2D:

    scale: int = static_field()

    def __init__(self, *, scale=1):
        self.scale = scale

    def __call__(self, x):

        @kernex.kmap(kernel_size=(-1, -1, -1),
                     strides=(1, 1, 1),
                     padding="valid")
        def _upsample2D(x):
            return x.repeat(self.scale, axis=2).repeat(self.scale, axis=1)

        return jnp.squeeze(jax.vmap(_upsample2D, in_axes=(0, ))(x),
                           axis=tuple(range(1, 4)))


@treeclass
class AdaptiveReLU:
    weight: jnp.ndarray

    def __init__(self):
        self.weight = jnp.array([1.0])

    def __call__(self, x):
        return jnp.maximum(0, self.weight * x)


@treeclass
class Sequential:

    layers: Sequence[treeclass]

    def __call__(self, x):
        for layer in self.layers:
            x = layer(x)
        return x
