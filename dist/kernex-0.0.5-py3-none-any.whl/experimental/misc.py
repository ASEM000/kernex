import jax 
import jax.numpy as jnp 
from typing import Callable
import functools

def diff(func:Callable,*args,**kwargs):
  
  # inline diff
  if len(args) > 0 or len(kwargs)>0 :
    return jax.grad(lambda *ar,**kw : jnp.sum(func(*ar,**kw)),*args,**kwargs)
  
  # @decorator diff with call
  elif len(args)== 0 and len(kwargs)==0 :
    @functools.wraps(func)
    def call(*ar,**kws):
      return jax.grad(lambda *ar,**kws : jnp.sum(func(*ar,**kws)))(*ar,**kws)
    return call